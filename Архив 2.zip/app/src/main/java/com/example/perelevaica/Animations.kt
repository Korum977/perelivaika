package com.example.perelevaica

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween

object Animations {
    enum class PouringAnimationType {
        LINEAR,
        CURVED,
        SPLASH
    }

    object Durations {
        const val POURING_ANIMATION_DURATION = 500
        const val COLOR_CHANGE_DURATION = 300
    }

    object Specs {
        val LINEAR_POURING = tween<Float>(
            durationMillis = Durations.POURING_ANIMATION_DURATION,
            easing = LinearEasing
        )

        val CURVED_POURING = tween<Float>(
            durationMillis = Durations.POURING_ANIMATION_DURATION,
            easing = FastOutSlowInEasing
        )

        val COLOR_CHANGE = tween<Float>(
            durationMillis = Durations.COLOR_CHANGE_DURATION
        )
    }
}