package com.example.perelevaica

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseOutBack
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.BlendModeColorFilterCompat
import androidx.core.graphics.BlendModeCompat
import com.airbnb.lottie.LottieProperty
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.airbnb.lottie.compose.rememberLottieDynamicProperties
import com.airbnb.lottie.compose.rememberLottieDynamicProperty

@Composable
fun TimeProgressBar(timeLeft: Int, totalTime: Int) {
    LinearProgressIndicator(
        progress = timeLeft.toFloat() / totalTime.toFloat(),
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
    )
}

@Composable
fun BottlesGrid(gameState: GameState) {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 100.dp),
        contentPadding = PaddingValues(8.dp)
    ) {
        items(gameState.bottles.size) { index ->
            Bottle(
                bottle = gameState.bottles[index],
                index = index,
                gameState = gameState
            )
        }
    }
}

@Composable
fun Bottle(bottle: Bottle, index: Int, gameState: GameState) {
    val isSelected = index == gameState.selectedBottle
    val isPouringFrom = gameState.isPouringFrom == index
    val isPouringTo = gameState.isPouringTo == index

    val pouringState = PouringAnimation.rememberPouringState()
    val animatedPouringState = PouringAnimation.animatePouringValues(pouringState.value)

    LaunchedEffect(isPouringFrom, isPouringTo) {
        if (isPouringFrom || isPouringTo) {
            PouringAnimation.animatePouring(pouringState)
        }
    }

    Card(
        modifier = Modifier
            .size(80.dp, 160.dp)
            .offset(y = animatedPouringState.offsetY)
            .graphicsLayer(rotationZ = animatedPouringState.tiltAngle)
            .clickable { gameState.selectBottle(index) },
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 8.dp else 1.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val bottleWidth = size.width * 0.8f
            val bottleHeight = size.height
            val bottleLeft = size.width * 0.1f
            
            // Draw bottle
            val bottleColor = Color(0xFFE0E0E0)
            val bottleBrush = Brush.verticalGradient(
                colors = listOf(bottleColor.copy(alpha = 0.7f), bottleColor),
                startY = 0f,
                endY = bottleHeight
            )
            drawRoundRect(
                brush = bottleBrush,
                topLeft = Offset(bottleLeft, 0f),
                size = Size(bottleWidth, bottleHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx())
            )
            
            // Draw bottle outline
            drawRoundRect(
                color = Color.White.copy(alpha = 0.5f),
                topLeft = Offset(bottleLeft, 0f),
                size = Size(bottleWidth, bottleHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()),
                style = Stroke(width = 2.dp.toPx())
            )

            // Draw contents
            val liquidHeight = bottleHeight / bottle.capacity
            bottle.contents.forEachIndexed { index, color ->
                val yOffset = bottleHeight - (index + 1) * liquidHeight
                val liquidBrush = Brush.verticalGradient(
                    colors = listOf(color.copy(alpha = 0.7f), color),
                    startY = yOffset,
                    endY = yOffset + liquidHeight
                )
                
                // Apply pouring animation
                val adjustedHeight = when {
                    isPouringFrom && index == bottle.contents.lastIndex -> 
                        liquidHeight * (1f - animatedPouringState.pouringProgress)
                    isPouringTo && index == bottle.contents.size -> 
                        liquidHeight * animatedPouringState.pouringProgress
                    else -> liquidHeight
                }
                
                drawRect(
                    brush = liquidBrush,
                    topLeft = Offset(bottleLeft, yOffset),
                    size = Size(bottleWidth, adjustedHeight)
                )
            }
            
            // Draw pouring animation
            if (isPouringFrom && animatedPouringState.step == PouringAnimation.PouringStep.POUR) {
                val pouringColor = PouringAnimation.getLiquidColor(bottle)
                val startX = bottleLeft + bottleWidth / 2
                val startY = 0f
                val endX = size.width + PouringAnimation.Offsets.POUR_OFFSET_X.toPx()
                val endY = size.height + PouringAnimation.Offsets.POUR_OFFSET_Y.toPx()

                val pouringPath = PouringAnimation.createPouringPath(
                    startX, startY, endX, endY, animatedPouringState.pouringProgress
                )

                drawPath(
                    path = pouringPath,
                    color = pouringColor,
                    style = Stroke(
                        width = 10.dp.toPx() * (1f - animatedPouringState.pouringProgress),
                        cap = StrokeCap.Round
                    )
                )
            }
            
            // Draw shine effect
            val shineColor = Color.White.copy(alpha = 0.3f)
            val shinePath = Path().apply {
                moveTo(bottleLeft + bottleWidth * 0.1f, 0f)
                lineTo(bottleLeft + bottleWidth * 0.2f, 0f)
                lineTo(bottleLeft + bottleWidth * 0.1f, bottleHeight)
                lineTo(bottleLeft, bottleHeight)
                close()
            }
            drawPath(
                path = shinePath,
                color = shineColor
            )
        }
    }
}

@Composable
fun LevelCompletedAlert(gameState: GameState, onNextLevel: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    
    LaunchedEffect(Unit) {
        visible = true
    }

    if (visible) {
        Dialog(
            onDismissRequest = { visible = false },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Card(
                modifier = Modifier
                    .wrapContentSize()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF4A90E2) // A safe, accessible blue color
                )
            ) {
                AnimatedVisibility(
                    visible = visible,
                    enter = fadeIn(animationSpec = tween(500)) + expandVertically(
                        animationSpec = tween(500, easing = EaseOutBack)
                    ),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Level ${gameState.currentLevel.ordinal + 1} Completed!",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        val dynamicProperties = rememberLottieDynamicProperties(
                            rememberLottieDynamicProperty(
                                property = LottieProperty.COLOR_FILTER,
                                value = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
                                    Color.Transparent.hashCode(),
                                    BlendModeCompat.SRC_ATOP
                                ),
                                keyPath = arrayOf(
                                    "**",
                                    "background"
                                )
                            )
                        )

                        val composition by rememberLottieComposition(
                            LottieCompositionSpec.Asset("cool-gold-badge.json")
                        )
                        val progress by animateLottieCompositionAsState(
                            composition,
                            iterations = LottieConstants.IterateForever
                        )
                        
                        if (composition != null) {
                            LottieAnimation(
                                modifier = Modifier.size(150.dp),
                                composition = composition,
                                progress = { progress },
                                dynamicProperties = dynamicProperties
                            )
                        } else {
                            Text(
                                "Animation failed to load",
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            "Moves: ${gameState.moves}",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        Button(
                            onClick = { 
                                visible = false
                                onNextLevel()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF34A853) // A safe, accessible green color
                            )
                        ) {
                            Text(
                                "Next Level",
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}