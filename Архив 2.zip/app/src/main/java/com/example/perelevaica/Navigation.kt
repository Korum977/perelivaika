 package com.example.perelevaica

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun GameNavigation() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "main_menu") {
        composable("main_menu") {
            MainMenu(
                onStartGame = { navController.navigate("level_select") },
                onSettings = { navController.navigate("settings") }
            )
        }
        composable("level_select") {
            LevelSelectScreen(
                onLevelSelected = { level ->
                    navController.navigate("game/$level")
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable("settings") {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        composable("game/{level}") { backStackEntry ->
            val level = backStackEntry.arguments?.getString("level")?.toIntOrNull() ?: 1
            val gameState = remember { GameState(Level.fromInt(level)) }
            PaintSortGame(
                gameState = gameState,
                onBackToMenu = { navController.popBackStack("main_menu", false) }
            )
        }
    }
}