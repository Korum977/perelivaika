package com.example.perelevaica

import androidx.compose.animation.core.*
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

object PouringAnimation {
    enum class PouringStep {
        IDLE,
        TILT_SOURCE,
        POUR,
        TILT_BACK_SOURCE,
        SETTLE_DESTINATION
    }

    data class PouringState(
        val step: PouringStep = PouringStep.IDLE,
        val progress: Float = 0f,
        val tiltAngle: Float = 0f,
        val offsetY: Dp = 0.dp,
        val pouringProgress: Float = 0f
    )

    object Durations {
        const val TILT_DURATION = 300
        const val POUR_DURATION = 800
        const val SETTLE_DURATION = 300
    }

    object Angles {
        const val TILT_ANGLE = 45f
    }

    object Offsets {
        val TILT_OFFSET_Y: Dp = 20.dp
        val POUR_OFFSET_X: Dp = 30.dp
        val POUR_OFFSET_Y: Dp = 40.dp
    }

    @Composable
    fun rememberPouringState(): MutableState<PouringState> {
        return remember { mutableStateOf(PouringState()) }
    }

    suspend fun animatePouring(pouringState: MutableState<PouringState>) {
        pouringState.value = pouringState.value.copy(step = PouringStep.TILT_SOURCE)
        delay(Durations.TILT_DURATION.toLong())

        pouringState.value = pouringState.value.copy(step = PouringStep.POUR)
        repeat(20) {
            pouringState.value = pouringState.value.copy(pouringProgress = (it + 1) / 20f)
            delay(Durations.POUR_DURATION / 20L)
        }

        pouringState.value = pouringState.value.copy(step = PouringStep.TILT_BACK_SOURCE)
        delay(Durations.TILT_DURATION.toLong())

        pouringState.value = pouringState.value.copy(step = PouringStep.SETTLE_DESTINATION)
        delay(Durations.SETTLE_DURATION.toLong())

        pouringState.value = PouringState() // Reset to IDLE state
    }

    @Composable
    fun animatePouringValues(pouringState: PouringState): PouringState {
        val tiltAngle by animateFloatAsState(
            targetValue = when {
                pouringState.step in listOf(PouringStep.TILT_SOURCE, PouringStep.POUR) -> Angles.TILT_ANGLE
                else -> 0f
            },
            animationSpec = tween(durationMillis = Durations.TILT_DURATION, easing = FastOutSlowInEasing)
        )

        val offsetY by animateDpAsState(
            targetValue = when {
                pouringState.step in listOf(PouringStep.TILT_SOURCE, PouringStep.POUR) -> -Offsets.TILT_OFFSET_Y
                else -> 0.dp
            },
            animationSpec = tween(durationMillis = Durations.TILT_DURATION, easing = FastOutSlowInEasing)
        )

        val pouringProgress by animateFloatAsState(
            targetValue = if (pouringState.step == PouringStep.POUR) pouringState.pouringProgress else 0f,
            animationSpec = tween(durationMillis = Durations.POUR_DURATION, easing = LinearEasing)
        )

        return pouringState.copy(
            tiltAngle = tiltAngle,
            offsetY = offsetY,
            pouringProgress = pouringProgress
        )
    }

    fun createPouringPath(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        progress: Float
    ): Path {
        return Path().apply {
            val controlX = endX
            val controlY = (startY + endY) / 2f

            moveTo(startX, startY)
            quadraticBezierTo(
                controlX,
                controlY,
                startX + (endX - startX) * progress,
                startY + (endY - startY) * progress
            )
        }
    }

    fun getLiquidColor(bottle: Bottle): Color {
        return bottle.contents.lastOrNull() ?: Color.Transparent
    }
}