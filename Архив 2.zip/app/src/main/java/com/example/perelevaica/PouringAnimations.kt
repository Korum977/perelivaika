package com.example.perelevaica

import androidx.compose.animation.core.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

object PouringAnimations {
    enum class PouringStep {
        IDLE,
        TILT_SOURCE,
        POUR,
        TILT_BACK_SOURCE,
        SETTLE_DESTINATION
    }

    object Durations {
        const val TILT_DURATION = 300
        const val POUR_DURATION = 800
        const val SETTLE_DURATION = 300
    }

    object Angles {
        val TILT_ANGLE = 45f
    }

    object Offsets {
        val TILT_OFFSET_Y: Dp = 20.dp
        val POUR_OFFSET_X: Dp = 30.dp
        val POUR_OFFSET_Y: Dp = 40.dp
    }

    object AnimationSpecs {
        val tiltSpec: TweenSpec<Float> = tween(
            durationMillis = Durations.TILT_DURATION,
            easing = FastOutSlowInEasing
        )

        val tiltDpSpec: TweenSpec<Dp> = tween(
            durationMillis = Durations.TILT_DURATION,
            easing = FastOutSlowInEasing
        )

        val pourSpec: TweenSpec<Float> = tween(
            durationMillis = Durations.POUR_DURATION,
            easing = LinearEasing
        )

        val settleSpec: TweenSpec<Float> = tween(
            durationMillis = Durations.SETTLE_DURATION,
            easing = LinearOutSlowInEasing
        )
    }
}