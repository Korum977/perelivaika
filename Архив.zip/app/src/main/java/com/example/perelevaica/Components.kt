package com.example.perelevaica

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseOutBack
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.BlendModeColorFilterCompat
import androidx.core.graphics.BlendModeCompat
import com.airbnb.lottie.LottieProperty
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.animateLottieCompositionAsState
import com.airbnb.lottie.compose.rememberLottieComposition
import com.airbnb.lottie.compose.rememberLottieDynamicProperties
import com.airbnb.lottie.compose.rememberLottieDynamicProperty

@Composable
fun TimeProgressBar(timeLeft: Int, totalTime: Int) {
    LinearProgressIndicator(
        progress = timeLeft.toFloat() / totalTime.toFloat(),
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
    )
}

@Composable
fun BottlesGrid(gameState: GameState) {
    val bottlesPerRow = 4
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        for (i in gameState.bottles.indices step bottlesPerRow) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                for (j in 0 until bottlesPerRow) {
                    val index = i + j
                    if (index < gameState.bottles.size) {
                        Bottle(gameState.bottles[index], index, gameState)
                    } else {
                        Spacer(modifier = Modifier.size(80.dp, 160.dp))
                    }
                }
            }
        }
    }
    
    if (gameState.isLevelCompleted) {
        LevelCompletedAlert(gameState){
            gameState.navigateToNextLevel()
        }
    }
}

@Composable
fun Bottle(bottle: Bottle, index: Int, gameState: GameState) {
    val isSelected = index == gameState.selectedBottle
    val pouringProgress by animateFloatAsState(
        targetValue = if (gameState.isPouringFrom == index) 1f else 0f,
        animationSpec = tween(durationMillis = 500)
    )
    
    Card(
        modifier = Modifier
            .size(80.dp, 160.dp)
            .clickable { gameState.selectBottle(index) },
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 8.dp else 1.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Draw bottle
            val bottleColor = Color(0xFFE0E0E0)
            val bottleBrush = Brush.verticalGradient(
                colors = listOf(bottleColor.copy(alpha = 0.7f), bottleColor),
                startY = 0f,
                endY = size.height
            )
            drawRoundRect(
                brush = bottleBrush,
                topLeft = Offset(size.width * 0.1f, 0f),
                size = Size(size.width * 0.8f, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx())
            )
            
            // Draw bottle outline
            drawRoundRect(
                color = Color.White.copy(alpha = 0.5f),
                topLeft = Offset(size.width * 0.1f, 0f),
                size = Size(size.width * 0.8f, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx()),
                style = Stroke(width = 2.dp.toPx())
            )

            // Draw contents
            var yOffset = size.height
            bottle.contents.forEachIndexed { contentIndex, color ->
                val liquidHeight = size.height / bottle.capacity
                yOffset -= liquidHeight
                val liquidBrush = Brush.verticalGradient(
                    colors = listOf(color.copy(alpha = 0.7f), color),
                    startY = yOffset,
                    endY = yOffset + liquidHeight
                )
                
                // Apply pouring animation
                val adjustedHeight = if (gameState.isPouringFrom == index) {
                    liquidHeight * (1f - pouringProgress)
                } else {
                    liquidHeight
                }
                
                drawRect(
                    brush = liquidBrush,
                    topLeft = Offset(size.width * 0.1f, yOffset + liquidHeight - adjustedHeight),
                    size = Size(size.width * 0.8f, adjustedHeight)
                )
            }
            
            // Draw shine effect
            val shineColor = Color.White.copy(alpha = 0.3f)
            val shinePath = androidx.compose.ui.graphics.Path().apply {
                moveTo(size.width * 0.2f, 0f)
                lineTo(size.width * 0.3f, 0f)
                lineTo(size.width * 0.2f, size.height)
                lineTo(size.width * 0.1f, size.height)
                close()
            }
            drawPath(
                path = shinePath,
                color = shineColor
            )
        }
    }
}

@Composable
fun LevelCompletedAlert(gameState: GameState, onNextLevel: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    
    LaunchedEffect(Unit) {
        visible = true
    }

    if (visible) {
        Dialog(
            onDismissRequest = { visible = false },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Card(
                modifier = Modifier
                    .wrapContentSize()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF4A90E2) // A safe, accessible blue color
                )
            ) {
                AnimatedVisibility(
                    visible = visible,
                    enter = fadeIn(animationSpec = tween(500)) + expandVertically(
                        animationSpec = tween(500, easing = EaseOutBack)
                    ),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            "Level ${gameState.currentLevel.ordinal + 1} Completed!",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        val dynamicProperties = rememberLottieDynamicProperties(
                            rememberLottieDynamicProperty(
                                property = LottieProperty.COLOR_FILTER,
                                value = BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
                                    Color.Transparent.hashCode(),
                                    BlendModeCompat.SRC_ATOP
                                ),
                                keyPath = arrayOf(
                                    "**",
                                    "background"
                                )
                            )
                        )

                        val composition by rememberLottieComposition(
                            LottieCompositionSpec.Asset("cool-gold-badge.json")
                        )
                        val progress by animateLottieCompositionAsState(
                            composition,
                            iterations = LottieConstants.IterateForever
                        )
                        
                        if (composition != null) {
                            LottieAnimation(
                                modifier = Modifier.size(150.dp),
                                composition = composition,
                                progress = { progress },
                                dynamicProperties = dynamicProperties
                            )
                        } else {
                            Text(
                                "Animation failed to load",
                                color = Color.White,
                                textAlign = TextAlign.Center
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            "Moves: ${gameState.moves}",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        Button(
                            onClick = { 
                                visible = false
                                onNextLevel()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF34A853) // A safe, accessible green color
                            )
                        ) {
                            Text(
                                "Next Level",
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}