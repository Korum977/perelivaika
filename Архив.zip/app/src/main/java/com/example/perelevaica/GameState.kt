package com.example.perelevaica

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

data class Bottle(val capacity: Int, val contents: List<Color>)

enum class Level(val bottleCount: Int, val colorCount: Int, val fullBottles: Int, val emptyBottles: Int, val moveLimit: Int? = null, val timeLimit: Int? = null, val specialColors: List<Color> = emptyList(), val stars: Int = 3) {
    LEVEL_1(3, 2, 2, 1),  // Две бутылки с двумя цветами
    LEVEL_2(3, 2, 2, 1),  // Две бутылки с двумя цветами и одной пустой
    LEVEL_3(4, 3, 3, 1),  // Три бутылки с тремя цветами и одной пустой
    LEVEL_4(5, 4, 4, 1),  // Четыре бутылки с четырьмя цветами и одной пустой
    LEVEL_5(5, 4, 4, 1),  // Четыре бутылки с четырьмя цветами и одной пустой
    LEVEL_6(6, 5, 5, 1),  // Пять бутылок с пятью цветами и одной пустой
    LEVEL_7(7, 6, 6, 1),  // Шесть бутылок с шестью цветами и одной пустой
    LEVEL_8(8, 7, 7, 1),  // Семь бутылок с семью цветами и одной пустой
    LEVEL_9(9, 8, 8, 1),  // Восемь бутылок с восемью цветами и одной пустой
    LEVEL_10(10, 9, 9, 1), // Девять бутылок с девятью цветами и одной пустой
    LEVEL_11(12, 10, 10, 2), // Десять бутылок с десятью цветами и двумя пустыми
    LEVEL_12(15, 12, 12, 3), // Двенадцать бутылок с двенадцатью цветами и тремя пустыми
    LEVEL_13(7, 5, 6, 1, moveLimit = 30),
    LEVEL_14(8, 6, 7, 1, timeLimit = 180),
    LEVEL_15(9, 7, 8, 1, specialColors = listOf(Color.Magenta, Color.Cyan));

    companion object {
        fun fromInt(value: Int): Level = values().firstOrNull { it.ordinal + 1 == value } ?: LEVEL_1
    }
}

class GameState(level: Level = Level.LEVEL_1) {
    var bottles by mutableStateOf<List<Bottle>>(emptyList())
    var selectedBottle by mutableStateOf<Int?>(null)
    var moves by mutableStateOf(0)
    var undoStack by mutableStateOf(emptyList<List<Bottle>>())
    var moveLimit by mutableStateOf<Int?>(null)
    var timeLeft by mutableStateOf<Int?>(null)
    var isGameOver by mutableStateOf(false)
    var isLevelCompleted by mutableStateOf(false)
    var currentLevel by mutableStateOf(level)
    var isPouringFrom by mutableStateOf<Int?>(null)
    var isPouringTo by mutableStateOf<Int?>(null)
    var pouringProgress by mutableStateOf(0f)

    init {
        reset(level)
    }

    fun reset(level: Level = currentLevel) {
        currentLevel = level
        initializeLevel(level.bottleCount, level.colorCount, level.fullBottles, level.emptyBottles, level.moveLimit, level.timeLimit, level.specialColors)
        selectedBottle = null
        moves = 0
        undoStack = emptyList()
        isGameOver = false
        isLevelCompleted = false
    }

    private fun initializeLevel(
        bottleCount: Int,
        colorCount: Int,
        fullBottles: Int,
        emptyBottles: Int,
        moveLimit: Int? = null,
        timeLimit: Int? = null,
        specialColors: List<Color> = emptyList()
    ) {
        val colors = generateColors(colorCount, specialColors)
        val totalSlots = fullBottles * 4
        val contents = generateContents(fullBottles, colors, totalSlots)
        bottles = List(bottleCount) { index ->
            if (index < fullBottles) {
                Bottle(4, contents.subList(index * 4, (index + 1) * 4))
            } else {
                Bottle(4, emptyList())
            }
        }
        this.moveLimit = moveLimit
        this.timeLeft = timeLimit
    }

    private fun generateColors(count: Int, specialColors: List<Color>): List<Color> {
        val baseColors = listOf(Color.Red, Color.Green, Color.Blue, Color.Yellow, Color.Magenta, Color.Cyan, Color.White, Color.Gray)
        return (baseColors.take(count - specialColors.size) + specialColors).shuffled()
    }

    private fun generateContents(fullBottles: Int, colors: List<Color>, totalSlots: Int): List<Color> {
        return List(totalSlots) { colors[it % colors.size] }.shuffled()
    }

    fun selectBottle(index: Int) {
        if (selectedBottle == null) {
            selectedBottle = index
        } else if (selectedBottle != index) {
            pourBetweenBottles(selectedBottle!!, index)
            selectedBottle = null
        } else {
            selectedBottle = null
        }
    }

    private fun pourBetweenBottles(fromIndex: Int, toIndex: Int) {
        val fromBottle = bottles[fromIndex]
        val toBottle = bottles[toIndex]

        if (fromBottle.contents.isNotEmpty() && toBottle.contents.size < toBottle.capacity) {
            val colorToPour = fromBottle.contents.last()
            if (true) {
                undoStack = undoStack + listOf(bottles)
                val amountToPour = minOf(
                    fromBottle.contents.takeLastWhile { it == colorToPour }.size,
                    toBottle.capacity - toBottle.contents.size
                )

                bottles = bottles.toMutableList().apply {
                    this[fromIndex] = fromBottle.copy(contents = fromBottle.contents.dropLast(amountToPour))
                    this[toIndex] = toBottle.copy(contents = toBottle.contents + List(amountToPour) { colorToPour })
                }
                moves++
                moveLimit?.let { if (moves >= it) checkGameOver() }
                checkLevelComplete()
            }
        }
    }

    fun pour(fromIndex: Int, toIndex: Int) {
        val fromBottle = bottles[fromIndex]
        val toBottle = bottles[toIndex]

        if (fromBottle.contents.isNotEmpty() && toBottle.contents.size < toBottle.capacity) {
            val colorToPour = fromBottle.contents.last()
            if (toBottle.contents.isEmpty() || toBottle.contents.last() == colorToPour) {
                isPouringFrom = fromIndex
                isPouringTo = toIndex
                pouringProgress = 0f
            }
        }
    }

    fun finishPouring() {
        isPouringFrom?.let { fromIndex ->
            isPouringTo?.let { toIndex ->
                pourBetweenBottles(fromIndex, toIndex)
            }
        }
        isPouringFrom = null
        isPouringTo = null
        pouringProgress = 0f
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            bottles = undoStack.last()
            undoStack = undoStack.dropLast(1)
            moves--
            selectedBottle = null
        }
    }

    private fun checkLevelComplete() {
        isLevelCompleted = bottles.all { bottle ->
            bottle.contents.isEmpty() || (bottle.contents.size == bottle.capacity && bottle.contents.toSet().size == 1)
        }
    }

    private fun checkGameOver() {
        isGameOver = true
    }

    fun updateTimeLeft() {
        timeLeft?.let {
            if (it > 0) {
                timeLeft = it - 1
            } else {
                checkGameOver()
            }
        }
    }

    fun isLevelComplete(): Boolean {
        return isLevelCompleted
    }

    fun navigateToNextLevel() {
        val nextLevelOrdinal = (currentLevel.ordinal + 1) % Level.values().size
        val nextLevel = Level.values()[nextLevelOrdinal]
        reset(nextLevel)
    }
}