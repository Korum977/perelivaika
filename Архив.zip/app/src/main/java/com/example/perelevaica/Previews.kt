 package com.example.perelevaica

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.perelevaica.ui.theme.PerelevaicaTheme

@Preview(showBackground = true)
@Composable
fun GameScreenPreview() {
    PerelevaicaTheme {
        GameNavigation()
    }
}

@Preview(showBackground = true)
@Composable
fun LevelSelectScreenPreview() {
    PerelevaicaTheme {
        LevelSelectScreen(onLevelSelected = {}, onBack = {})
    }
}